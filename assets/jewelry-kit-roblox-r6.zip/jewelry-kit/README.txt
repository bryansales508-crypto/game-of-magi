JEWELRY KIT for the Roblox R6 body - 36 pieces, 8 charms, 4 engraving patterns
8 of the pieces have a charm slot, so there are 92 shapes before colors.

FOLDERS = WHICH BODY PART THE PIECE BELONGS TO
  head/  torso/  right_arm/  left_arm/  right_leg/  left_leg/
  Arm and leg pieces come in a right and a left version (mirror images).
  Earrings are a pair in one file.

THE ONE RULE FOR PLACING THEM
  Every file's origin is the CENTRE of its R6 body part (Head, Torso, Right Arm, ...).
  Put the piece at the same position and rotation as that body part and it is in place.
  Because the origin is the part's centre, scaling a piece together with its body part
  (taller, wider, older characters) keeps it sitting in the right spot.
  pieces.csv lists every file, its body part, its triangle count, and where the middle of
  each mesh sits relative to the body part centre, in case your importer re-centres meshes.

WHICH WAY IS FRONT
  In the files the character faces +Z, up is +Y, and the character's right arm is at -X
  (the standard glTF layout). If a piece comes in facing backwards, turn it 180 degrees
  about Y. It is the same fix for every piece.

MESHES AND MATERIALS
  Each file has a ..._Metal mesh and, if the piece has stones, a ..._Gems mesh.
  Metal: pick a Material (Metal works well) and a Color.
  Gems: their own mesh so they can have their own Color, or glow with Neon.
  engraving/: optional grayscale tiling patterns for the metal mesh (TextureID or a
  SurfaceAppearance ColorMap). The part's Color tints them. The metal UVs are laid out to
  tile, so the pattern repeats across a piece.

CHARMS
  Files ending in __Hilal, __Coin, __Teardrop, __Star, __Khamsa, __Eye, __Bell or __Tassel
  are the same piece with a different charm already attached. Use whichever you want.
  charms/ has the 8 charms on their own (origin = the point they hang from) and slots.csv
  lists where each charm hangs on each piece, if you would rather attach them in game.

GOOD TO KNOW
  * Sizes are studs. Set the importer's scale unit to Stud.
  * Everything is rigid: nothing swings.
  * R6 has no fingers, so each ring is a normal small ring half sunk into the outside face
    of the arm near the bottom, as if the finger were hidden inside the block. The three
    rings sit on three different "fingers", so all three can be worn at once.
  * Bands that go round an arm or leg dip slightly into the torso or the other leg.
    That is hidden while standing and shows only as the limb swings.
  * I could not test the import into Roblox Studio from here.
