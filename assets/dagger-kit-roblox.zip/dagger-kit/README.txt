DAGGER KIT - 13 blades, 10 handles, 6 grip patterns (780 daggers before colors)
Any blade fits any handle, and any pattern fits any grip.

FILES
  blades/Blade_01_Straight.glb ... Blade_13_Cleaver.glb  one mesh each
      Blade_12_Lawlab is two strands woven flat: about 0.33 studs wide and 0.1 thick, like the other blades.
  handles/Handle_01_Classic.glb ... Handle_10_Talon.glb  2-3 meshes each:
      _Fittings = guard, collar, pommel (plain metal, tint with Color)
      _Grip     = the part you hold (this is the mesh that takes a pattern)
      _Gem      = only on Handle 10 (try the Neon material)
  patterns/Grip_1_CordWrap.png ... Grip_6_SmoothBone.png  512 x 512, grayscale, tileable
      Grip_6_SmoothBone is the plain one: tint it ivory for bone, or any color for a solid grip.

HOW THE PIECES LINE UP
  Every file uses the same origin: the point where blade meets handle.
  Blades point up (+Y) from the origin, handles hang down (-Y) from it.
  So if the blade and handle sit at the same position and rotation, they are assembled.
  The middle of the grip (where the hand goes) is about 0.42 studs below the origin on every handle.

IMPORTING INTO ROBLOX STUDIO (3D Importer)
  1. The numbers in these files are already studs. Set the importer's scale unit to Stud.
  2. Turn on the options that keep the scene position and put the pivot at the scene origin,
     so each part keeps the shared origin described above.
  3. Blade and Fittings: no texture needed. Pick a Material (Metal works well) and a Color.
  4. Grip: upload one of the pattern PNGs and put it on the grip mesh (TextureID or a
     SurfaceAppearance ColorMap). The patterns are grayscale on purpose - the part's Color tints them.

SIZES
  A whole dagger is roughly 2.3 to 2.7 studs long. Triangle counts: blades 56-720, handles 496-1104.
